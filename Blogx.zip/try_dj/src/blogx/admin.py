from django.contrib import admin

from .models import blogpost

admin.site.register(blogpost)