from django.apps import AppConfig


class BlogxConfig(AppConfig):
    name = 'blogx'
