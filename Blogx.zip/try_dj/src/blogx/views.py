from django.http import Http404
from django.shortcuts import render, get_object_or_404
from .forms import (
    BlogPostForm,
    BlogPostModelForm,
)
from .models import blogpost


# def blog_post_detail_page(request, slug):
# queryset = blogpost.objects.filter(slug=slug)
# if queryset.count() == 0:
#   raise Http404
# obj = queryset.first()
# obj = get_object_or_404(blogpost, slug=slug)
# template_name = "blog_post_detail.html"
# context = {"object": obj}
# return render(request, template_name, context)


def blog_post_list_view(request):
    form=BlogPostForm(request.POST or None)
    if form.is_valid():
        print(forms.cleaned_data)
    qs = blogpost.objects.all()
    template_name = "blog_post_list.html"
    context = {'object_list': qs}
    return render(request, template_name, context)


def blog_post_create_view(request):
    form = BlogPostModelForm(request.POST or None)
    if form.is_valid():
        obj= form.save(commit=False)
        obj.save()
        # obj = blogpost.objects.create(**form.cleaned_data)
        form = BlogPostModelForm()
    template_name = "form.html"
    context = {'form': form}
    return render(request, template_name, context)


def blog_post_detail_view(request, slug):
    obj = get_object_or_404(blogpost, slug=slug)
    template_name = "blog_post_detail.html"
    context = {"object": obj}
    return render(request, template_name, context)


def blog_post_update_view(request):
    obj = get_object_or_404(blogpost, slug=slug)
    template_name = "blog_post_update.html"
    context = {"object": obj}
    return render(request, template_name, context)


def blog_post_delete_view(request):
    obj = get_object_or_404(blogpost, slug=slug)
    template_name = "blog_post_delete.html"
    context = {"object": obj}
    return render(request, template_name, context)
