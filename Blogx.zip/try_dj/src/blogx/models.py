from django.db import models

class blogpost(models.Model):
    slug=models.SlugField(unique=True)
    title = models.CharField(max_length=120)
    content=models.TextField(null=True, blank=True )